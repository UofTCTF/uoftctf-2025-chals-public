#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf("Here is your flag: uoftctf{fake_flag}\n");
    return 0;
}