#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf("uoftctf{fake_flag}\n");
    return 0;
}